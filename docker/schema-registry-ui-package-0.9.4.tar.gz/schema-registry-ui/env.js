var clusters = [
  {
    NAME: "DEV",
    SCHEMA_REGISTRY: "http://localhost:8081",
    COLOR: "black"
  }
];
